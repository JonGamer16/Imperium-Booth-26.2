# Centralized ability tuning knobs — set on load (called from main), like main/ability_cooldowns.
# Keep gameplay numbers here instead of scattering them through the ability functions.


# Shared abilities
    # Leap Feather (abilities/leap, Livvy + Meowdy): vertical dampening of the look-driven launch.
    #   Kept fraction of look-Y = numerator / #LeapDampDiv. Grounded keeps more (no jump lift);
    #   airborne keeps less (the jump already supplied lift). Formerly borrowed #constant.* from
    #   the vendored player_motion lib; the summit-core lib doesn't define #constant.3, so these
    #   now live here.
    scoreboard players set #LeapDampGround im.param 3
    scoreboard players set #LeapDampAir im.param 2
    scoreboard players set #LeapDampDiv im.param 10

# Livvy
    # Lifesteal: damage score (1/10 HP) needed for 1 soup; excludes damage taken.
    scoreboard players set #lsThreshold im_lifesteal 80
    # Escalation: flat score ADDED to the requirement per soup already converted this life, so the
    #   Nth soup costs #lsThreshold + #lsStep*(N-1). Resets on death/re-kit (livvy/givekit).
    #   Why it exists: at a flat 160 the conversion is a permanent 50% of damage dealt, which makes
    #   Livvy literally unkillable whenever an opponent's DPS on her is under half of hers on them —
    #   a hard threshold, not a curve, which is what made her matchups swing all-or-nothing. A flat
    #   adder makes cumulative healing grow with the SQUARE ROOT of damage dealt while incoming
    #   damage grows linearly, so the immortality case disappears without touching the first soup
    #   (still 160) — the ability stays exactly as visible in the first ~20s as it is now.
    #   >> TUNING KNOB: 0 disables escalation entirely (flat #lsThreshold forever, pre-2026-08
    #      behaviour). 40 = the Nth soup costs 16/20/24/28... HP dealt. Higher = harsher tail. <<
    scoreboard players set #lsStep im_lifesteal 20
    # Venom Bite: flat lifesteal score added per melee hit Livvy lands on a venom-affected target
    #   (imperium:combat/venom_bite -> internal/venom_bite). Stacks on top of the hit's normal score.
    #   Reference: #lsThreshold is 160, so 40 ~= a quarter-soup of extra credit per venomed hit.
    scoreboard players set #VenomLsBonus im_lifesteal 40

    # Venom DoT (imperium:venom, kits/livvy/venom_apply + venom_tick):
    #   Duration = total tag lifetime (ticks); Interval = ticks between damage hits.
    #   (Damage-per-hit stays a literal in venom_tick — the /damage command needs a literal.)
    scoreboard players set #VenomDuration im.param 63
    scoreboard players set #VenomInterval im.param 7

    # Web Throw: how long a thrown web (cobweb block display) lingers before despawning. 20t = 1s.
    scoreboard players set #WebDuration im.param 80

# Smokey — Smoke Bomb: lifetime (ticks) of the artificial smoke cloud (kits/smokey/smoke_init).
    scoreboard players set #SmokeDuration im.param 200

    # Grappling Rod (kits/smokey/grapple_launch): launch toward the bobber, distance-proportional.
    #   Lateral  = horizontal (x,z) pull divisor — lower = stronger.
    scoreboard players set #GrappleLateral im.param 10
    #   VertPull = vertical (y) pull divisor       — lower = stronger.
    scoreboard players set #GrappleVertPull im.param 10
    #   Vertical = static upward impulse added on top (1/10000 blocks/tick, like leap's pop).
    scoreboard players set #GrappleVertical im.param 4000
    #   Max      = speed cap on the pull, per axis (1/10000 b/t); -1 = unlimited. Applied before
    #              the static Vertical pop, so the pop always lands regardless of the cap.
    scoreboard players set #GrappleMax im.param 20000

# Mummy
    #   Grappling Rod (kits/mummy/mgrapple_*): yanks the hooked entity to the Mummy.
        #   Enter Reciprocal strength factor (lower = stronger)
        scoreboard players set #MummyGrappleLateral im.param 10
        scoreboard players set #MummyGrappleVertPull im.param 10
        #   Vertical: should be high enough to lift the target off the ground into an arc.
        scoreboard players set #MummyGrappleVertical im.param 9000
        scoreboard players set #MummyGrappleMax im.param 20000
        #   CastSpeed: integer multiplier on the bobber's launch Motion (faster/farther cast).
        scoreboard players set #MummyCastSpeed im.param 2

    # Energy meter (kits/mummy/energy_*): a 0..#MummyEnergyMax pool shown on the action bar, spent by
        #   Golem Throw / Energy Barrier / Mace Smash and refilled by eating an Energy Crystal.
        scoreboard players set #MummyEnergyMax im.param 100
        #   Energy a Mummy spawns / re-kits with.
        scoreboard players set #MummyEnergyStart im.param 100
        #   Energy gained per Energy Crystal consumed.
        scoreboard players set #MummyEnergyCrystal im.param 50
    #   Crystal Bomb (kits/mummy/crystal_bomb): placing a crystal as a bomb (sneak-consume) refunds
    #   reduced resources vs eating it — this much energy instead of the full #MummyEnergyCrystal, and
    #   only the instant heal (the regen the consumable applies is stripped). See crystal_bomb.
        scoreboard players set #MummyCrystalBombEnergy im.param 60
        #   Crystal Bomb fuse: ticks from placement to detonation (20t = 1s).
        scoreboard players set #BombFuse im.param 20
        #   Crystal Bomb blast: damage = #BombMaxDamage at the center, falling #BombDropoff per block out to
        #   #BombRange blocks (whole damage units, dealt in 1-block rings via execute-as + /damage @s).
        #   imperium:bomb type — no knockback (won't fight the launch); still reduced by the target's armor.
        scoreboard players set #BombMaxDamage im.param 16
        scoreboard players set #BombRange im.param 5
        scoreboard players set #BombDropoff im.param 1
        #   Blast launch: upward impulse on everything the blast hits — INCLUDING the placer (a built-in
        #   self-boost; the placer still takes no damage). In 1/10000 b/t; ~10000 (1.0 b/t) ≈ 5 blocks up.
        scoreboard players set #BombLaunch im.param 10000
    #   Per-ability costs. An ability calls kits/mummy/energy_spend {cost:<n>} and only fires when it
    #   reports success (enough banked). Wire each WIP enchant to read its cost here.
        scoreboard players set #MummyGolemThrowCost im.param 25
        scoreboard players set #MummySmashCost im.param 25
    #   Energy Barrier (kits/mummy/barrier_*): hold sneak to spend energy as absorption hearts; hits
    #   drain the hearts (and the meter), releasing sneak refunds the leftover.
    #   Scale = absorption HP granted per 100 energy (20 -> full 100 energy = 20 HP = 10 hearts).
    #   NOTE: the absorption amplifier in barrier_raise must cover EnergyMax*Scale/100 HP — at amp 4
    #   the cap is (4+1)*4 = 20 HP, which exactly fits the default. Raise the amp if you raise Scale.
        scoreboard players set #MummyBarrierScale im.param 20
        #   Minimum energy required to raise the barrier (no putting up a sliver of a shield).
        scoreboard players set #MummyBarrierMin im.param 10

    # Golem Throw (kits/mummy/golem_*): a charged heavy hit that flings the victim up and deals bonus
    #   damage (the ×1.5 lives in the golem_throw enchant — a literal there, not a score).
        #   ChargeTime = wind-up ticks (while sneaking) before the hit arms (20t = 1s).
        scoreboard players set #GolemChargeTime im.param 30
        #   Window = ticks the armed hit stays usable; miss the window and the charge drops, re-winding for
        #   a fresh cycle. ChargeEnd (derived) = the charge value at which the window closes.
        scoreboard players set #GolemWindow im.param 30
        scoreboard players operation #GolemChargeEnd im.param = #GolemChargeTime im.param
        scoreboard players operation #GolemChargeEnd im.param += #GolemWindow im.param
        #   Launch = upward impulse applied to the victim, in 1/10000 blocks/tick (12000 = 1.2 b/t pop).
        scoreboard players set #GolemLaunch im.param 8000
        #   HookLaunch = upward impulse on the Mummy ITSELF when it Golem-Throws an enemy it's currently
        #   grappling (the "throw + ride the recoil" combo), same 1/10000 b/t units. See golem_hook_recoil.
        scoreboard players set #GolemHookLaunch im.param 8000

# Rastus
    # Air Dodge: Launch power (10000 * blocks/tick)
        scoreboard players set #DodgePower im.param 4000

    # Strike & Parry: shared charge time (idle ticks of not attacking/blocking before
    # both are armed) and the parry's full-deflect window (ticks of Resistance V + KB immunity
    # after a charged shield raise). 20 ticks = 1s.
        scoreboard players set #StrikeCharge im.param 12
        scoreboard players set #ParryWindow im.param 3

# Levent
    # Charge Attack: idle ticks of not attacking OR raising the shield before the next hit gets
    # the boost (bonus damage, reach, knockback). 20 ticks = 1s; the slow Light Rod wants a touch
    # longer wind-up than Rastus's Strike.
    scoreboard players set #LeventCharge im.param 14