# Leap Feather: shared looking-direction dash.
# Triggered by consuming any item flagged {im_leap_feather:1b}.
advancement revoke @s only imperium:use_leap_feather

#   Directional Vector
#       Impulse in the player's looking direction, added on top of running momentum.
#       Strength is score x 0.0001 blocks/tick. Grounded and airborne are tuned apart so
#       the jump-leap technique can be balanced (airborne already carries jump momentum).
#       >> TUNING KNOBS: grounded / airborne strength. <<
execute unless predicate imperium:on_ground run \
    scoreboard players set $strength player_motion.api.launch 12000
#       On Ground Conditional
execute if predicate imperium:on_ground run \
    scoreboard players set $strength player_motion.api.launch 15000

function player_motion:api/launch_looking

#   Vertical Dampening
#       Keep a fraction (numerator/#LeapDampDiv) of the look-driven y. Grounded keeps more since
#       it has no jump velocity; airborne keeps less because the jump already supplied lift.
#       Constants live in im.param (main/ability_parameters) — the summit-core player_motion lib
#       only defines a handful of #constant.* values, so we no longer borrow its objective.
#       >> TUNING KNOBS: #LeapDampGround / #LeapDampAir numerators. <<
execute if predicate imperium:on_ground run \
    scoreboard players operation \
    @s player_motion.internal.motion.y \
    *= #LeapDampGround im.param
scoreboard players operation \
    @s player_motion.internal.motion.y \
    /= #LeapDampDiv im.param
#       On Ground Conditional
execute unless predicate imperium:on_ground run \
    scoreboard players operation \
    @s player_motion.internal.motion.y \
    *= #LeapDampAir im.param

#   Constant Vector
#       Flat upward floor (0.0001 b/t units). Grounded gets a real pop; airborne gets
#       little, since the jump already carries you up -- this is what tames the difference.
#       >> TUNING KNOBS: grounded / airborne baseline. <<
execute unless predicate imperium:on_ground run \
    scoreboard players add @s player_motion.internal.motion.y 4000
#       On Ground Conditional
execute if predicate imperium:on_ground run \
    scoreboard players add @s player_motion.internal.motion.y 6000

# Livvy: 1 second of Strength riding the leap
effect give @s[tag=im.kit_livvy] minecraft:strength 1 0

# Spend a charge so the cooldown begins once the feather is used. Leap is slot A for
# both leap kits (Livvy, Meowdy); update_cooldowns clamps this at >= 0.
scoreboard players remove @s im_cdUsesA 1
