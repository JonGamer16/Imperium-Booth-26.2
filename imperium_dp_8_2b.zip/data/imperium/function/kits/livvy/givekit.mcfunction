#   Livvy the Vampire Spider

function imperium:util/clear_kit

#   [ARMOR]
execute unless items entity @s armor.head * run \
    item replace entity @s armor.head with \
        netherite_helmet[\
            !max_damage,\
            attribute_modifiers=[\
                {type:"armor",amount:15,operation:"add_value",slot:"head",id:"head"},\
                {type:"armor_toughness",amount:8,operation:"add_value",slot:"head",id:"head"},\
                {type:"sneaking_speed",amount:1,operation:"add_value",slot:"head",id:"head"},\
                {type:"movement_speed",amount:0.2,operation:"add_multiplied_base",slot:"head",id:"head"},\
                {type:"step_height",amount:0.5,operation:"add_value",slot:head,id:"head"},\
                {type:"safe_fall_distance",amount:6,operation:"add_value",slot:head,id:"head"},\
                {type:"fall_damage_multiplier",amount:-0.5,operation:"add_value",slot:head,id:"head"},\
                {type:"attack_knockback",amount:1,operation:"add_value",slot:"head",id:"head"},\
                {type:"knockback_resistance",amount:0.44,operation:"add_value",slot:"head",id:"head"},\
            ],\
            item_model="minecraft:leather_helmet",\
            equippable={slot:head,asset_id:"minecraft:leather"},\
            dyed_color=4194304,\
            trim={material:"redstone",pattern:"silence"},\
            custom_name={color:"red",italic:false,text:"Vampire Hood"},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.chest * run \
    item replace entity @s armor.chest with \
        netherite_chestplate[\
            !max_damage,\
            !attribute_modifiers,\
            item_model="minecraft:leather_chestplate",\
            equippable={slot:chest,asset_id:"minecraft:leather"},\
            dyed_color=4194304,\
            trim={material:"redstone",pattern:"silence"},\
            custom_name={color:"red",italic:false,text:"Vampire Chestplate"},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.legs * run \
    item replace entity @s armor.legs with \
        netherite_leggings[\
            !max_damage,\
            !attribute_modifiers,\
            item_model="minecraft:leather_leggings",\
            equippable={slot:legs,asset_id:"minecraft:leather"},\
            dyed_color=4194304,\
            trim={material:"redstone",pattern:"silence"},\
            custom_name={color:"red",italic:false,text:"Vampire Leggings"},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.feet * run \
    item replace entity @s armor.feet with \
        netherite_boots[\
            !max_damage,\
            !attribute_modifiers,\
            item_model="minecraft:leather_boots",\
            equippable={slot:feet,asset_id:"minecraft:leather"},\
            dyed_color=4194304,\
            trim={material:"redstone",pattern:"silence"},\
            custom_name={color:"red",italic:false,text:"Vampire Boots"},\
            custom_data={"imperium_kit":1b},\
        ] 1

#   [MELEE] Fang
#       6 | 2, Crits, Lifesteal
execute unless items entity @s hotbar.0 * run \
    item replace entity @s hotbar.0 with \
        netherite_sword[\
            !max_damage,\
            item_model="minecraft:ghast_tear",\
            attribute_modifiers=[\
                {type:"attack_damage",amount:4,operation:"add_value",slot:"mainhand",id:"base_attack_damage"},\
                {type:"attack_speed",amount:-2,operation:"add_value",slot:"mainhand",id:"base_attack_speed"}\
            ],\
            enchantments={"imperium:crits":2,"imperium:lifesteal":1},\
            custom_name={text:"Lifesteal Fang",color:"red",italic:false},\
            custom_data={"imperium_kit":1b}\
        ] 1

#   [SLOT 1] Leap Feather
function imperium:kits/livvy/cd1_feather

#   [SLOT 2] Throwable Web (multi-charge, count-based — mirrors Meowdy's arrows)
#       Give the full 3-web stack now and seed the count-based stock from #Livvy constants. The
#       loop recounts im_cdUsesB on each throw; cd2_web refills one web at a time.
loot give @s loot imperium:livvy/webs
scoreboard players operation @s im_cdMaxB = #Livvy im_cdMaxB
scoreboard players operation @s im_cdUsesB = #Livvy im_cdMaxB
scoreboard players operation @s im_cdFloorB = #Livvy im_cdFloorB
#       Seed the web throw-sampler to the current used-stat so loop_kit's first tick sees a zero
#       delta (no stale recount) — the count starts authoritative from the full stack given above.
scoreboard players operation @s im_webUsedPrev = @s im_webUsedStat

#   [SLOT 3] Acid Potion
function imperium:kits/livvy/cd3_potion

#   [HEALING] Beetroot Soup
#       12 x 8 HP
loot give @s loot imperium:livvy/healing

#   Ability Cooldowns
scoreboard players operation @s im_abilityCdA = #Livvy im_abilityCdA
scoreboard players operation @s im_abilityCdB = #Livvy im_abilityCdB
scoreboard players operation @s im_abilityCdC = #Livvy im_abilityCdC

#   Lifesteal: start banking from zero, sync prev so prior damage isn't counted
scoreboard players set @s im_lifesteal 0
scoreboard players operation @s im_lsPrev = @s im_lsDealt
#   ...and reset the escalating soup cost. arena/respawn re-runs this whole givekit on every death,
#   so this IS the reset-on-death hook — no separate death trigger needed. im_lsNeed is the cached
#   cost of the next soup; at zero conversions that's just #lsThreshold, so seed it directly rather
#   than doing the multiply. (Note this also resets on a kit SWAP, which is only reachable from the
#   kit room between rounds — it would become a reset exploit if mid-round swapping is ever added.)
scoreboard players set @s im_lsConversions 0
scoreboard players operation @s im_lsNeed = #lsThreshold im_lifesteal

tag @s add im.kit_livvy
