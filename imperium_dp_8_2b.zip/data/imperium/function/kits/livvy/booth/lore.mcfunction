# Livvy the Vampire Spider — hidden lore. Triggered by sneak-clicking the booth stand.
# Paste the fighter's lore into the body line(s) below; keep the red color formatting.
tellraw @s \
[   "",\
    {   text:"\n  "},\
    {color:"red",bold:true,italic:false,\
        text:"Livvy - The Vampire Spider"},\
    {bold:false,\
        text:"\n\n"},\
    {color:"red",italic:true,\
        text:" This innocent little village girl liked to play with the bugs on the ground, \
        but one day she suffered a fatal spider bite. Her parents would do anything \
        to save her. Luckily, they found a traveling 'doctor', who managed to \
        stop the poison! All it took was a fusion that transformed her into a \
        half-spider abomination with fangs, 8 eyes, and a killer instinct, yet she \
        still remembers who she was.\n"}\
]

# Sticker 2 (Historian): record this fighter's lore as read, then check for all seven.
tag @s add im.lore_livvy
function imperium:booth/check_lore
