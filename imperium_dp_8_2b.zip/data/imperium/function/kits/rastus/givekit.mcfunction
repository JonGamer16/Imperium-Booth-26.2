#   Rastus the Duelist

function imperium:util/clear_kit

#   [ARMOR]
execute unless items entity @s armor.head * run \
    item replace entity @s armor.head with \
        netherite_helmet[\
            attribute_modifiers=[\
                {type:"armor",amount:17,operation:"add_value",slot:"head",id:"head"},\
                {type:"armor_toughness",amount:4,operation:"add_value",slot:"head",id:"head"},\
                {type:"movement_speed",amount:0.2,operation:"add_multiplied_base",slot:"head",id:"head"},\
                {type:"attack_knockback",amount:1,operation:"add_value",slot:"head",id:"head"},\
                {type:"knockback_resistance",amount:0.44,operation:"add_value",slot:"head",id:"head"},\
            ],\
            !max_damage,\
            item_model="minecraft:leather_helmet",\
            equippable={slot:head,asset_id:"minecraft:leather"},\
            dyed_color=3949738,\
            trim={material:"lapis",pattern:"dune"},\
            custom_name={text:"Dueling Helmet",color:blue,italic:false},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.chest * run \
    item replace entity @s armor.chest with \
        netherite_chestplate[\
            !attribute_modifiers,\
            !max_damage,\
            item_model="minecraft:chainmail_chestplate",\
            equippable={slot:chest,asset_id:"minecraft:chainmail"},\
            trim={material:"lapis",pattern:"raiser"},\
            custom_name={text:"Dueling Chestplate",color:blue,italic:false},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.legs * run \
    item replace entity @s armor.legs with \
        netherite_leggings[\
            !attribute_modifiers,\
            !max_damage,\
            item_model="minecraft:chainmail_leggings",\
            equippable={slot:legs,asset_id:"minecraft:chainmail"},\
            trim={material:"lapis",pattern:"sentry"},\
            custom_name={text:"Dueling Leggings",color:blue,italic:false},\
            custom_data={"imperium_kit":1b},\
        ] 1
execute unless items entity @s armor.feet * run \
    item replace entity @s armor.feet with \
        netherite_boots[\
            !attribute_modifiers,\
            !max_damage,\
            item_model="minecraft:leather_boots",\
            equippable={slot:feet,asset_id:"minecraft:leather"},\
            dyed_color=3949738,\
            trim={material:"iron",pattern:"raiser"},\
            custom_name={text:"Dueling Boots",color:blue,italic:false},\
            custom_data={"imperium_kit":1b},\
        ] 1

#   [MELEE] Lightning Rapier
#       2 | 7, +1.0 Knockback
execute unless items entity @s hotbar.0 * run \
    item replace entity @s hotbar.0 with \
        netherite_sword[\
            attribute_modifiers=[\
                {type:"attack_damage",amount:1.5,operation:"add_value",slot:"mainhand",id:"base_attack_damage"},\
                {type:"attack_speed",amount:4,operation:"add_value",slot:"mainhand",id:"base_attack_speed"},\
                {type:"attack_knockback",amount:-1.0,operation:"add_value",slot:"mainhand",id:"attack_knockback"},\
                {type:"entity_interaction_range",amount:-1,operation:"add_value",slot:"mainhand",id:"entity_interaction_range"}],\
            enchantments={"imperium:focus_attack":1},\
            attack_range={hitbox_margin:0.5},\
            damage_type="imperium:light",\
            piercing_weapon={deals_knockback:true},\
            minimum_attack_charge=1.0,\
            !max_damage,\
            item_model="minecraft:iron_sword",\
            custom_name={text:"Lightning Rapier",color:blue,italic:false},\
            custom_data={"imperium_kit":1b},\
        ] 1

#   [SLOT 1] Buckler
function imperium:kits/rastus/cd1_shield

#   [SLOT 2] [Empty]

#   [SLOT 3] [Empty]

#   [HEALING] Splash Healing 2 Potion
#       16 x 8 HP
loot give @s loot imperium:rastus/healing

#   Ability Cooldowns
scoreboard players operation @s im_abilityCdA = #Rastus im_abilityCdA
scoreboard players operation @s im_abilityCdB = #Rastus im_abilityCdB
scoreboard players operation @s im_abilityCdC = #Rastus im_abilityCdC

#   Air Dodge charges (slot C): start with the full 5-dash stock. The player copy of
#   im_cdMaxC is what arms the engine's freeze (update_cooldowns reads @s, not #Rastus) —
#   without it the slot never freezes and cd3_dodge refills past the cap.
scoreboard players operation @s im_cdMaxC = #Rastus im_cdMaxC
scoreboard players operation @s im_cdUsesC = #Rastus im_cdMaxC
#   ...and the freeze FLOOR, which clear_kit zeroed. update_cooldowns reads @s here too, so
#   without this the full-stock clamp bottoms out at 0 instead of #Rastus im_cdFloorC (25 =
#   base 50 at 50% stock): a topped-up slot pre-banks its WHOLE cooldown, so the first dash
#   after a top-up came back on the very next hit instead of costing 2.5 HP of damage.
#   (It also left slot C sitting at exactly 0 while full, re-dispatching cd3_dodge — an
#   instant no-op return — on every single damage event.) Mirrors livvy/meowdy givekit.
scoreboard players operation @s im_cdFloorC = #Rastus im_cdFloorC

tag @s add im.kit_rastus
