# Booth kit-stand click — runs AS the exact clicker, so no UUID matching is needed.
#
# NO battlegrounds assign here. imperium:kits/meowdy/booth/select owns the
# summit.battlegrounds:api/assign_kit call, so an accepted click registers the kit exactly once.
# Calling assign here as well was the double-assign bug: every click printed
# "[Baobab Battlegrounds] You have selected ..." TWICE (once from here, once from select). It also
# fired above both guards below, so sneaking to read the lore — or a click refused by the equip
# rate-limit — still re-assigned the kit in the Battlegrounds without equipping anything.
#
# This function is DOUBLE-WIRED and that is tolerated, not accidental: Summit's Interactions API
# calls it from the stand's summit.interactable tag (see the deploy log), and
# imperium:booth/select_meowdy calls it from player_interacted_with_entity, which is what
# makes the stand work in a bare test world with no Interactions API. Nothing revokes that
# advancement, so it fires once per player and then goes dormant. Either way both paths can land on
# the same tick; im.equip_cd below absorbs the duplicate, and with the assign call gone the
# duplicate is now silent.

# Sneak = read the lore. Never selects, never assigns.
execute if predicate imperium:sneaking run return run function imperium:kits/meowdy/booth/lore

# Equip rate-limit: im.equip_cd is cleared every second by loop_1s. Spam-clicking a stand
# re-runs the whole im_givekit pipeline (clears + loot gives), so deny re-equips inside the window.
execute if entity @s[tag=im.equip_cd] run return run title @s actionbar {text:"Kit swap recharging...",color:"red"}
tag @s add im.equip_cd

function imperium:kits/meowdy/booth/select
