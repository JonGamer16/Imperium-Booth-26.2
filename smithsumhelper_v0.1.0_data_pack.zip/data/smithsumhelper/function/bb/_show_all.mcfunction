function smithsumhelper:bb/show_all
