function smithsumhelper:bb/copy
