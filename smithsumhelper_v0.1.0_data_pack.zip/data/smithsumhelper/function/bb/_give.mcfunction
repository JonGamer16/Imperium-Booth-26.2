scoreboard objectives add smithsumhelper.calc dummy
give @s item_frame[custom_data={smithsumhelper: {bb: true}}, entity_data={id: "minecraft:item_frame", Tags: ["smithsumhelper.bb"]}]
