advancement revoke @s only smithsumhelper:bb/place
execute as @e[type=item_frame, tag=smithsumhelper.bb] at @s rotated as @s positioned ^ ^ ^-1 align xyz run function smithsumhelper:bb/place/nested_execute_1
function smithsumhelper:bb/if_else_0
