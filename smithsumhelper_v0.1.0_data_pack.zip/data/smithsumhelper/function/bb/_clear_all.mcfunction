kill @e[type=block_display, tag=smithsumhelper.bb.box]
data modify storage smithsumhelper:calc bb.boxes set value []
