function smithsumhelper:bb/show_all/loop/nested_macro_0 with storage smithsumhelper:calc bb.temp[0]
data remove storage smithsumhelper:calc bb.temp[0]
execute if data storage smithsumhelper:calc bb.temp[0] run function smithsumhelper:bb/show_all/loop
