kill @e[type=block_display, tag=smithsumhelper.bb.box]
