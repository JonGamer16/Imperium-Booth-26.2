data modify storage smithsumhelper:calc bb.text_builder set value {current: ""}
data modify storage smithsumhelper:calc bb.temp set value []
data modify storage smithsumhelper:calc bb.temp set from storage smithsumhelper:calc bb.boxes
scoreboard players set id smithsumhelper.calc 0
execute if data storage smithsumhelper:calc bb.temp[0] run function smithsumhelper:bb/copy/loop
data modify storage smithsumhelper:calc bb.text_builder.current set string storage smithsumhelper:calc bb.text_builder.current 1
function smithsumhelper:bb/copy/nested_macro_0 with storage smithsumhelper:calc bb.text_builder
