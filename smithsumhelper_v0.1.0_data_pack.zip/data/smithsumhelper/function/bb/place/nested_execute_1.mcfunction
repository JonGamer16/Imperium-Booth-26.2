execute summon marker run function smithsumhelper:bb/place/nested_execute_0
kill @s
