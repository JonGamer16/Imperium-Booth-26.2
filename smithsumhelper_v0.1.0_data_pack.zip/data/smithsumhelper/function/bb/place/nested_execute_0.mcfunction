execute store result score x1 smithsumhelper.calc run data get entity @s Pos[0] 1
execute store result score y1 smithsumhelper.calc run data get entity @s Pos[1] 1
execute store result score z1 smithsumhelper.calc run data get entity @s Pos[2] 1
kill @s
