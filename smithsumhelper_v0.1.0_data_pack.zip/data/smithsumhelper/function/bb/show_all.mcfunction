kill @e[type=block_display, tag=smithsumhelper.bb.box]
data modify storage smithsumhelper:calc bb.temp set value []
data modify storage smithsumhelper:calc bb.temp set from storage smithsumhelper:calc bb.boxes
execute if data storage smithsumhelper:calc bb.temp[0] run function smithsumhelper:bb/show_all/loop
