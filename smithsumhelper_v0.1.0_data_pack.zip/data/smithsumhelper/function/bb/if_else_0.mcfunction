execute if data storage smithsumhelper:calc bb.selected_pos run return run function smithsumhelper:bb/if_else_0/nested_execute_0
data modify storage smithsumhelper:calc bb.selected_pos set value {x: 0, y: 0, z: 0}
execute store result storage smithsumhelper:calc bb.selected_pos.x int 1 run scoreboard players get x1 smithsumhelper.calc
execute store result storage smithsumhelper:calc bb.selected_pos.y int 1 run scoreboard players get y1 smithsumhelper.calc
execute store result storage smithsumhelper:calc bb.selected_pos.z int 1 run scoreboard players get z1 smithsumhelper.calc
