scoreboard players add id smithsumhelper.calc 1
execute store result storage smithsumhelper:calc bb.text_builder.id int 1 run scoreboard players get id smithsumhelper.calc
data modify storage smithsumhelper:calc bb.text_builder merge from storage smithsumhelper:calc bb.temp[0].booth
function smithsumhelper:bb/copy/loop/nested_macro_0 with storage smithsumhelper:calc bb.text_builder
data remove storage smithsumhelper:calc bb.temp[0]
execute if data storage smithsumhelper:calc bb.temp[0] run function smithsumhelper:bb/copy/loop
