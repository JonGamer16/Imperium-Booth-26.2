$tellraw @s {"click_event":{"action":"copy_to_clipboard","value":'{$(current)}'},"color":"aqua","text":"click to copy to clipboard","underlined":true}
