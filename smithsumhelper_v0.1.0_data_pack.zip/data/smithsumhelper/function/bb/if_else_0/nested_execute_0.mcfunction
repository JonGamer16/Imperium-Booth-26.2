execute store result score x2 smithsumhelper.calc run data get storage smithsumhelper:calc bb.selected_pos.x 1
execute store result score y2 smithsumhelper.calc run data get storage smithsumhelper:calc bb.selected_pos.y 1
execute store result score z2 smithsumhelper.calc run data get storage smithsumhelper:calc bb.selected_pos.z 1
scoreboard players operation minx smithsumhelper.calc = x1 smithsumhelper.calc
scoreboard players operation minx smithsumhelper.calc < x2 smithsumhelper.calc
scoreboard players operation maxx smithsumhelper.calc = x1 smithsumhelper.calc
scoreboard players operation maxx smithsumhelper.calc > x2 smithsumhelper.calc
scoreboard players operation miny smithsumhelper.calc = y1 smithsumhelper.calc
scoreboard players operation miny smithsumhelper.calc < y2 smithsumhelper.calc
scoreboard players operation maxy smithsumhelper.calc = y1 smithsumhelper.calc
scoreboard players operation maxy smithsumhelper.calc > y2 smithsumhelper.calc
scoreboard players operation minz smithsumhelper.calc = z1 smithsumhelper.calc
scoreboard players operation minz smithsumhelper.calc < z2 smithsumhelper.calc
scoreboard players operation maxz smithsumhelper.calc = z1 smithsumhelper.calc
scoreboard players operation maxz smithsumhelper.calc > z2 smithsumhelper.calc
tellraw @a {text: "added [", extra: [{score: {name: "minx", objective: "smithsumhelper.calc"}}, ", ", {score: {name: "miny", objective: "smithsumhelper.calc"}}, ", ", {score: {name: "minz", objective: "smithsumhelper.calc"}}, "], [", {score: {name: "maxx", objective: "smithsumhelper.calc"}}, ", ", {score: {name: "maxy", objective: "smithsumhelper.calc"}}, ", ", {score: {name: "maxz", objective: "smithsumhelper.calc"}}, "]"]}
data remove storage smithsumhelper:calc bb.selected_pos
scoreboard players operation $i0 bolt.expr.temp = maxx smithsumhelper.calc
scoreboard players operation $i0 bolt.expr.temp -= minx smithsumhelper.calc
scoreboard players add $i0 bolt.expr.temp 1
scoreboard players operation $i1 bolt.expr.temp = maxy smithsumhelper.calc
scoreboard players operation $i1 bolt.expr.temp -= miny smithsumhelper.calc
scoreboard players add $i1 bolt.expr.temp 1
scoreboard players operation $i2 bolt.expr.temp = maxz smithsumhelper.calc
scoreboard players operation $i2 bolt.expr.temp -= minz smithsumhelper.calc
scoreboard players add $i2 bolt.expr.temp 1
data modify storage bolt.expr:temp i0 set value {x: 0, y: 0, z: 0, size: [0, 0, 0], booth: {xmin: 0, xmax: 0, ymin: 0, ymax: 0, zmin: 0, zmax: 0}}
execute store result storage bolt.expr:temp i0.x int 1 run scoreboard players get minx smithsumhelper.calc
execute store result storage bolt.expr:temp i0.y int 1 run scoreboard players get miny smithsumhelper.calc
execute store result storage bolt.expr:temp i0.z int 1 run scoreboard players get minz smithsumhelper.calc
execute store result storage bolt.expr:temp i0.size[0] int 1 run scoreboard players get $i0 bolt.expr.temp
execute store result storage bolt.expr:temp i0.size[1] int 1 run scoreboard players get $i1 bolt.expr.temp
execute store result storage bolt.expr:temp i0.size[2] int 1 run scoreboard players get $i2 bolt.expr.temp
execute store result storage bolt.expr:temp i0.booth.xmin int 1 run scoreboard players get minx smithsumhelper.calc
execute store result storage bolt.expr:temp i0.booth.xmax int 1 run scoreboard players get maxx smithsumhelper.calc
execute store result storage bolt.expr:temp i0.booth.ymin int 1 run scoreboard players get miny smithsumhelper.calc
execute store result storage bolt.expr:temp i0.booth.ymax int 1 run scoreboard players get maxy smithsumhelper.calc
execute store result storage bolt.expr:temp i0.booth.zmin int 1 run scoreboard players get minz smithsumhelper.calc
execute store result storage bolt.expr:temp i0.booth.zmax int 1 run scoreboard players get maxz smithsumhelper.calc
data modify storage smithsumhelper:calc bb.boxes append from storage bolt.expr:temp i0
execute store result score $i0 bolt.expr.temp run data get storage smithsumhelper:calc bb.boxes[-1].size[0] 10
execute store result storage smithsumhelper:calc bb.boxes[-1].size[0] float 0.1 run scoreboard players add $i0 bolt.expr.temp 1
execute store result score $i0 bolt.expr.temp run data get storage smithsumhelper:calc bb.boxes[-1].size[1] 10
execute store result storage smithsumhelper:calc bb.boxes[-1].size[1] float 0.1 run scoreboard players add $i0 bolt.expr.temp 1
execute store result score $i0 bolt.expr.temp run data get storage smithsumhelper:calc bb.boxes[-1].size[2] 10
execute store result storage smithsumhelper:calc bb.boxes[-1].size[2] float 0.1 run scoreboard players add $i0 bolt.expr.temp 1
function smithsumhelper:bb/_show_all
