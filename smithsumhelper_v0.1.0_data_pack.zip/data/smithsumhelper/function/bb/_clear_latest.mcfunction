data remove storage smithsumhelper:calc bb.boxes[-1]
function smithsumhelper:bb/_show_all
